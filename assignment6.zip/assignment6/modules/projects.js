require('dotenv').config();
const Sequelize = require('sequelize');
const Project = require('../models/Project');  
const Sector = require('../models/Sector');  

// Define Sequelize instance to connect to the database
const sequelize = new Sequelize('neondb', 'neondb_owner', 'JjmksZd5BFY9', {
  host: 'ep-odd-darkness-a5cbvnyy.us-east-2.aws.neon.tech',
  dialect: 'postgres',
  port: 5432,
  dialectOptions: {
    ssl: { rejectUnauthorized: false },
  },
});

// Initialize Sequelize instance
function Initialize() {
    return sequelize.sync()
        .then(() => {
            console.log('Database synced successfully');
        })
        .catch((error) => {
            throw new Error(`Error syncing database: ${error.message}`);
        });
}

// Get all projects including their sector data
function getAllProjects() {
    return Project.findAll({
        include: [Sector]
    })
    .then(projects => {
        console.log("Fetched Projects:", projects);
        return projects;
    })
    .catch(error => {
        console.error("Error fetching projects:", error.message);
        throw new Error(`Error fetching projects: ${error.message}`);
    });
}


// Get a project by its ID
function getProjectById(projectId) {
    return Project.findOne({
        where: { id: projectId },
        include: [Sector]  // Include Sector data
    })
    .then(project => {
        if (project) {
            return project;
        } else {
            throw new Error(`Unable to find requested project with ID ${projectId}`);
        }
    })
    .catch(error => {
        throw new Error(`Error fetching project by ID: ${error.message}`);
    });
}

// Get projects by sector name
function getProjectsBySector(sector) {
    return Project.findAll({
        include: [Sector],
        where: {
            '$Sector.sector_name$': {
                [Sequelize.Op.iLike]: `%${sector}%`
            }
        }
    })
    .then(projects => {
        if (projects.length > 0) {
            return projects;
        } else {
            throw new Error(`Unable to find projects in the sector: ${sector}`);
        }
    })
    .catch(error => {
        throw new Error(`Error fetching projects by sector: ${error.message}`);
    });
}

// Add a new project to the database
function addProject(projectData) {
    return Project.create({
        title: projectData.title,
        feature_img_url: projectData.feature_img_url,
        summary_short: projectData.summary_short,
        intro_short: projectData.intro_short,
        impact: projectData.impact,
        original_source_url: projectData.original_source_url,
        sector_id: projectData.sector_id  
    })
    .then(() => {
        console.log("New project added successfully");
    })
    .catch(err => {
        throw new Error(err.errors[0].message); 
    });
}

// Get all sectors from the database
function getAllSectors() {
    return Sector.findAll()
        .then(sectors => {
            if (sectors.length > 0) {
                return sectors;
            } else {
                throw new Error("No sectors found");
            }
        })
        .catch(error => {
            throw new Error(`Error fetching sectors: ${error.message}`);
        });
}

// Delete a project by its ID
function deleteProject(projectId) {
    return Project.destroy({
        where: { id: projectId }
    })
    .then(deletedCount => {
        if (deletedCount > 0) {
            console.log(`Project with ID ${projectId} deleted successfully`);
            return true;
        } else {
            throw new Error(`Project with ID ${projectId} not found`);
        }
    })
    .catch(error => {
        throw new Error(`Error deleting project: ${error.message}`);
    });
}

// Edit an existing project
function editProject(projectId, projectData) {
    return Project.update(projectData, {
        where: { id: projectId }
    })
    .then(([updatedCount]) => {
        if (updatedCount > 0) {
            console.log(`Project with ID ${projectId} updated successfully`);
            return true;
        } else {
            throw new Error(`Project with ID ${projectId} not found`);
        }
    })
    .catch(error => {
        throw new Error(`Error updating project: ${error.message}`);
    });
}

// Export the functions as a module
module.exports = {
    Initialize,
    getAllProjects,
    getProjectById,
    getProjectsBySector,
    addProject,
    getAllSectors,
    deleteProject,
    editProject
};
