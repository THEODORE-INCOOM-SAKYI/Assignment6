const mongoose = require('mongoose');
const bcrypt = require('bcryptjs'); // Added bcryptjs for hashing passwords
require('dotenv').config();

const Schema = mongoose.Schema;

// Define the userSchema
const userSchema = new Schema({
  userName: {
    type: String,
    unique: true, // Ensures the userName is unique
  },
  password: String,
  email: String,
  loginHistory: [
    {
      dateTime: Date,
      userAgent: String,
    },
  ],
});

// Variable to hold the User model
let User;

// Function to initialize the connection to MongoDB
function initialize() {
  return new Promise(function (resolve, reject) {
    let db = mongoose.createConnection(process.env.MONGODB);

    db.on('error', (err) => {
      reject(err);
    });

    db.once('open', () => {
      User = db.model("users", userSchema);
      resolve();
    });
  });
}

// Function to register a new user
function registerUser(userData) {
  return new Promise((resolve, reject) => {
    if (userData.password !== userData.password2) {
      reject("Passwords do not match");
      return;
    }

    // Hash the password
    bcrypt
      .hash(userData.password, 10) // Salt rounds = 10
      .then((hash) => {
        // Replace the plain text password with the hashed one
        userData.password = hash;

        let newUser = new User({
          userName: userData.userName,
          password: userData.password,
          email: userData.email,
          loginHistory: [],
        });

        newUser
          .save()
          .then(() => {
            resolve();
          })
          .catch((err) => {
            if (err.code === 11000) {
              reject("User Name already taken");
            } else {
              reject(`There was an error creating the user: ${err}`);
            }
          });
      })
      .catch(() => {
        reject("There was an error encrypting the password");
      });
  });
}

// Function to check a user's login credentials
function checkUser(userData) {
  return new Promise((resolve, reject) => {
    User.find({ userName: userData.userName })
      .then((users) => {
        if (users.length === 0) {
          reject(`Unable to find user: ${userData.userName}`);
          return;
        }

        const user = users[0];

        // Compare the provided password with the hashed password in the database
        bcrypt
          .compare(userData.password, user.password)
          .then((result) => {
            if (!result) {
              reject(`Incorrect Password for user: ${userData.userName}`);
            } else {
              if (user.loginHistory.length === 8) {
                user.loginHistory.pop(); // Remove the oldest entry
              }

              user.loginHistory.unshift({
                dateTime: new Date().toString(),
                userAgent: userData.userAgent,
              });

              User.updateOne(
                { userName: user.userName },
                { $set: { loginHistory: user.loginHistory } }
              )
                .then(() => {
                  resolve(user);
                })
                .catch((err) => {
                  reject(`There was an error verifying the user: ${err}`);
                });
            }
          })
          .catch(() => {
            reject(`Unable to verify password for user: ${userData.userName}`);
          });
      })
      .catch(() => {
        reject(`Unable to find user: ${userData.userName}`);
      });
  });
}

// Export the functions
module.exports = {
  initialize,
  registerUser,
  checkUser,
};
