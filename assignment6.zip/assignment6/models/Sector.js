const { Sequelize, DataTypes } = require('sequelize');

const sequelize = new Sequelize('neondb', 'neondb_owner', 'JjmksZd5BFY9', {
  host: 'ep-odd-darkness-a5cbvnyy.us-east-2.aws.neon.tech',
  dialect: 'postgres',
  port: 5432,
  dialectOptions: {
    ssl: { rejectUnauthorized: false },
  },
});

const Sector = sequelize.define('Sector', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  sector_name: {
    type: DataTypes.STRING,
  }
});

module.exports = Sector;
