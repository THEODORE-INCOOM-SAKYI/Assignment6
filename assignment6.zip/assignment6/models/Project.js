// models/Project.js
module.exports = (sequelize, DataTypes) => {
    const Project = sequelize.define('Project', {
      title: {
        type: DataTypes.STRING,
        allowNull: false
      },
      feature_img_url: {
        type: DataTypes.STRING,
        allowNull: true  // Allow it to be NULL if optional
      },
      summary_short: {
        type: DataTypes.STRING,
        allowNull: true
      },
      intro_short: {
        type: DataTypes.STRING,
        allowNull: true
      },
      impact: {
        type: DataTypes.STRING,
        allowNull: true
      },
      original_source_url: {
        type: DataTypes.STRING,
        allowNull: true
      },
      sector_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
          model: 'Sectors',  // Name of the related table
          key: 'id'
        }
      }
    }, {
      tableName: 'Projects', // Optional: Explicitly define the table name (if not following pluralization convention)
      timestamps: true,      // Optional: Automatically add createdAt & updatedAt columns
    });
  
    // Association
    Project.associate = (models) => {
      Project.belongsTo(models.Sector, { foreignKey: 'sector_id', as: 'sector' });
    };
  
    return Project;
  };
  