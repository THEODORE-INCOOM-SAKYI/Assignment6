/********************************************************************************
*  WEB322 – Assignment 05
* 
*  I declare that this assignment is my own work in accordance with Seneca's
*  Academic Integrity Policy:
* 
*  https://www.senecacollege.ca/about/policies/academic-integrity-policy.html
* 
*  Name: ________Theodore Incoom Sakyi______________ Student ID: ______151883220________ Date: ______11/25/24________
*
*  Published URL: __________________https://assignment5-blond-eight.vercel.app/_________________________________________
*
********************************************************************************/

const express = require("express");
const path = require("path");
const { Sequelize, DataTypes } = require("sequelize");
const authData = require('./modules/auth-service'); // Require auth-service module
const clientSessions = require("client-sessions"); // Require client-sessions module

require('dotenv').config();

const app = express();
const PORT = 3000;

const sequelize = new Sequelize(process.env.DB_NAME, process.env.DB_USER, process.env.DB_PASSWORD, {
  host: process.env.DB_HOST,
  dialect: 'postgres',
  port: process.env.DB_PORT,
  dialectOptions: {
    ssl: { rejectUnauthorized: false },
  },
});

// Configure client-sessions middleware
app.use(clientSessions({
  cookieName: "session", // Name of the cookie
  secret: "yourSecretKey", // Change to a secure secret key
  duration: 2 * 60 * 60 * 1000, // Session duration (2 hours)
  activeDuration: 1000 * 60 * 5 // Extends session by 5 minutes if active
}));

// Middleware to make the session object available in templates
app.use((req, res, next) => {
  res.locals.session = req.session;
  next();
});

// Middleware to check if a user is logged in
function ensureLogin(req, res, next) {
  if (!req.session.user) {
    res.redirect("/login");
  } else {
    next();
  }
}

// Models
const Sector = sequelize.define('Sector', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  sector_name: {
    type: DataTypes.STRING,
  }
}, {
  timestamps: false,
});

const Project = sequelize.define('Project', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  title: {
    type: DataTypes.STRING,
  },
  feature_img_url: {
    type: DataTypes.STRING,
  },
  summary_short: {
    type: DataTypes.TEXT,
  },
  intro_short: {
    type: DataTypes.TEXT,
  },
  impact: {
    type: DataTypes.TEXT,
  },
  original_source_url: {
    type: DataTypes.STRING,
  }
}, {
  timestamps: false
});

Project.belongsTo(Sector, { foreignKey: 'sector_id' });

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.static(path.join(__dirname, "public")));
app.use(express.urlencoded({ extended: true })); // Handle form submissions

const { addProject, getAllSectors, deleteProject, getProjectById, editProject } = require('./modules/projects'); 

// Routes
app.get("/", (req, res) => {
  res.render("home", { page: "/" });
});

app.get("/about", (req, res) => {
  res.render("about", { page: "/about" });
});

// Adding New Routes
app.get("/login", (req, res) => {
  res.render("login", { errorMessage: "", userName: "" });
});

app.get("/register", (req, res) => {
  res.render("register", { errorMessage: "", successMessage: "", userName: "" });
});

app.post("/register", (req, res) => {
  authData.registerUser(req.body)
    .then(() => {
      res.render("register", { errorMessage: "", successMessage: "User created", userName: "" });
    })
    .catch(err => {
      res.render("register", { errorMessage: err, successMessage: "", userName: req.body.userName });
    });
});

app.post("/login", (req, res) => {
  req.body.userAgent = req.get('User-Agent'); // Add the User-Agent to the request body

  authData.checkUser(req.body)
    .then(user => {
      req.session.user = {
        userName: user.userName,
        email: user.email,
        loginHistory: user.loginHistory
      };
      res.redirect("/solutions/projects");
    })
    .catch(err => {
      res.render("login", { errorMessage: err, userName: req.body.userName });
    });
});

app.get("/logout", (req, res) => {
  req.session.reset(); // Reset the session
  res.redirect("/");
});

app.get("/userHistory", ensureLogin, (req, res) => {
  res.render("userHistory", { user: req.session.user });
});

// Existing Routes
app.get("/solutions/projects", (req, res) => {
  projectsModule.getAllProjects()
    .then(projects => {
      res.render("projects", { projects, project: null });
    })
    .catch(err => {
      res.status(500).render("500", { message: `Error retrieving projects: ${err.message}` });
    });
});

// Protected Routes for Adding/Editing/Deleting Projects
app.get("/solutions/addProject", ensureLogin, (req, res) => {
  getAllSectors()
    .then(sectors => {
      res.render("addProject", { sectors, page: "/solutions/addProject" });
    })
    .catch(err => {
      res.render("500", { message: `Error fetching sectors: ${err}` });
    });
});

app.get('/solutions/editProject/:id', ensureLogin, async (req, res) => {
    try {
      const projectId = req.params.id;
      const projectData = await getProjectById(projectId); 
      const sectorData = await getAllSectors(); 
      
      res.render('editProject', { sectors: sectorData, project: projectData });
    } catch (err) {
      res.status(404).render('404', { message: err.message });
    }
});

app.post("/solutions/addProject", ensureLogin, (req, res) => {
  const projectData = req.body;

  addProject(projectData)
    .then(() => {
      res.redirect("/solutions/projects");
    })
    .catch(err => {
      res.render("500", { message: `I'm sorry, but we have encountered the following error: ${err}` });
    });
});

app.get('/solutions/deleteProject/:id', ensureLogin, async (req, res) => {
    try {
      const projectId = req.params.id;
      await deleteProject(projectId); 
      res.redirect('/solutions/projects'); 
    } catch (err) {
      res.render('500', { message: `I'm sorry, but we have encountered the following error: ${err}` });
    }
});

app.post('/solutions/editProject', ensureLogin, async (req, res) => {
    try {
      const { id, title, feature_img_url, summary_short, intro_short, impact, original_source_url, sector_id } = req.body;
      const projectData = { title, feature_img_url, summary_short, intro_short, impact, original_source_url, sector_id };
      
      await editProject(id, projectData); 
      res.redirect('/solutions/projects'); 
    } catch (err) {
      res.render('500', { message: `I'm sorry, but we have encountered the following error: ${err}` });
    }
});

// Error Handling
app.use((req, res) => {
  res.status(404).render("404", { message: "Sorry, we couldn't find the page you're looking for." });
});

app.use((err, req, res, next) => {
  res.status(500).render("500", { message: "Internal server error. Please try again later." });
});

// Initialize authData and start the server
sequelize.sync()
  .then(() => {
    console.log("Database connected and models synced.");
    return authData.initialize(); // Initialize authData
  })
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  })
  .catch(err => {
    console.error("Unable to start the server:", err);
  });
